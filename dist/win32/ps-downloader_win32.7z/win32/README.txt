# utils for pnp download

# ps-downloader

![ps-downloader](http://i.imgur.com/QKPuxDp.png)

    Usage: ps-downloader.py [options] <url> 

    Options:
      --version             show program's version number and exit
      -h, --help            show this help message and exit

      Download Options:
        These options control downloads.
    
        --filename=FILENAME
                            Use as base name ex: myname_0001, myname_0002, ...
        --username=USERNAME
                            your siteusername/email.
        --password=PASSWORD
                            your site password.

## Usage Examples:

Just download images from the site *(public shared - no user need it)*

    ps-downloader.py "http://foo.url"

Just download images from the site *(public shared)* and save images as "*test_0001.jpg*", "*test_0002.jpg*"

    ps-downloader.py --filename "test" "http://foo.url"

Download protected images from the site, **need a valid user**

    ps-downloader.py --username "foo@foo.com" --password "mypass" "http://foo.url"